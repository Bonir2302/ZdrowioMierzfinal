#ifndef FUNKCJE_H
#define FUNKCJE_H
#include <iostream>

using namespace std;

string wczytajposilek();

double iloscpobierz(double il);

void ilosczamien(double il);

void podsumujkalorie(double il);

void czynowydzien(double il);

double wczytajkalorie(double il);

void wpiszdopliku(string posilek, double kcal);

#endif
