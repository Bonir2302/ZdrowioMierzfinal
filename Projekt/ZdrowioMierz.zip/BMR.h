#pragma once
#include<iostream>	
using namespace std;

class BMR
{
	double waga;
	int wzrost;
	int wiek;
	string plec;

public:
	BMR() {};
	void wylicz();
};
