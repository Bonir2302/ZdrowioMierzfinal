#pragma once
#include<iostream>
using namespace std;

class BMI
{
	double masa;
	double wzrost;

public:
	BMI() {};
	//virtual~BMI() {};
	void oblicz();
};
